% clean environment
clc;
close all; 
clear;
workspace; 

[fraises, vert] = trouverFraises(imread('Fraises.jpg'));