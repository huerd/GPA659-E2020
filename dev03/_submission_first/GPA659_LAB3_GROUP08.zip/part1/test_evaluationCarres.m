% clean environment
clc;
close all; 
clear;
workspace; 

result01 = compterCarres(imread('carres.png'));