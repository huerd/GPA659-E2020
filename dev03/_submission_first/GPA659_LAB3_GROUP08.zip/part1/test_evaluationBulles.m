% clean environment
clc;
close all; 
clear;
workspace; 

[bulle, groupes] = compteBulles(imread('bulles.bmp'));